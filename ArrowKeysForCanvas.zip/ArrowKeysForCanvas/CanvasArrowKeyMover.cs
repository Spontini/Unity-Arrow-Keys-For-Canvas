using UnityEngine;
using UnityEditor;
using System.Collections;

namespace ArrowKeysForCanvas
{
    [InitializeOnLoad]
    public class CanvasArrowKeyMover
    {
        // Variables
        private static float _moveSpeed = 0.1f;
        private static Rect _windowRect = new Rect(4, 645, 200, 40);
        private static Vector2 _relativePosition = new Vector2(4, 1);
        private static Coroutine _moveCoroutine;

        // Property to get and set moveSpeed with clamping
        public static float moveSpeed
        {
            get => _moveSpeed;
            set => _moveSpeed = Mathf.Clamp(value, 0.01f, 100f);
        }

        static CanvasArrowKeyMover()
        {
            SceneView.duringSceneGui += OnSceneGUI;
        }

        // Method called during the Scene View GUI rendering
        private static void OnSceneGUI(SceneView sceneView)
        {
            Event e = Event.current;

            if (e != null && Selection.activeGameObject != null && SceneView.currentDrawingSceneView.in2DMode)
            {
                if (IsChildOfCanvas(Selection.activeGameObject))
                {
                    if (e.type == EventType.KeyDown)
                    {
                        if (_moveCoroutine != null)
                            EditorApplication.update -= _moveCoroutine;

                        _moveCoroutine = EditorApplication.update.StartCoroutine(MoveObjectSmoothly(Selection.activeGameObject, e));
                    }
                    else if (e.type == EventType.KeyUp)
                    {
                        // Stop coroutine if necessary
                        if (_moveCoroutine != null)
                            EditorApplication.update -= _moveCoroutine;
                    }
                }
            }

            // Draw the move speed panel if conditions are met
            if (Selection.activeGameObject != null && SceneView.currentDrawingSceneView.in2DMode && IsChildOfCanvas(Selection.activeGameObject))
            {
                DrawMoveSpeedPanel(sceneView.position);
            }
        }

        // Coroutine for smooth movement
        private static IEnumerator MoveObjectSmoothly(GameObject obj, Event e)
        {
            Vector3 targetPosition = obj.transform.position;
            switch (e.keyCode)
            {
                case KeyCode.UpArrow:
                    targetPosition += Vector3.up * _moveSpeed;
                    break;
                case KeyCode.DownArrow:
                    targetPosition += Vector3.down * _moveSpeed;
                    break;
                case KeyCode.LeftArrow:
                    targetPosition += Vector3.left * _moveSpeed;
                    break;
                case KeyCode.RightArrow:
                    targetPosition += Vector3.right * _moveSpeed;
                    break;
            }

            float t = 0f;
            Vector3 startPosition = obj.transform.position;
            while (t < 1f)
            {
                t += Time.deltaTime;
                obj.transform.position = Vector3.Lerp(startPosition, targetPosition, t);
                yield return null;
            }
        }

        // Check if a GameObject is a child of a Canvas
        private static bool IsChildOfCanvas(GameObject obj)
        {
            Transform current = obj.transform;
            while (current != null)
            {
                if (current.GetComponent<Canvas>() != null)
                {
                    return true;
                }
                current = current.parent;
            }
            return false;
        }

        // Draw the move speed panel in the Scene View
        private static void DrawMoveSpeedPanel(Rect sceneViewRect)
        {
            Handles.BeginGUI();

            _windowRect.x = _relativePosition.x;
            _windowRect.y = sceneViewRect.height - _windowRect.height - _relativePosition.y;

            _windowRect = GUILayout.Window(123456, _windowRect, DrawWindowContents, "Arrow Key Move Speed", "window");

            _windowRect.x = Mathf.Clamp(_windowRect.x, 4, sceneViewRect.width - _windowRect.width - 4);
            _windowRect.y = Mathf.Clamp(_windowRect.y, 4, (sceneViewRect.height - 25) - _windowRect.height - 4);

            _relativePosition = new Vector2(_windowRect.x, sceneViewRect.height - _windowRect.y - _windowRect.height);

            Handles.EndGUI();
        }

        // Draw the contents of the move speed window
        private static void DrawWindowContents(int windowID)
        {
            EditorGUI.BeginChangeCheck();
            moveSpeed = EditorGUILayout.FloatField("Move Speed", moveSpeed);
            if (EditorGUI.EndChangeCheck())
            {
                SceneView.RepaintAll();
            }

            GUI.DragWindow(new Rect(0, 0, _windowRect.width, _windowRect.height));
        }
    }
}